# ArenaOS Desktop — Deployment Windows

## Objetivo
ArenaOS debe instalarse y operar localmente en la PC del club, sin depender del internet para vender, abrir caja, controlar estaciones o cerrar caja.

## Estado validado antes de producción

Checklist validado en la rama/paquete actual:

- Portable funcionó 100%.
- Installer funciona.
- `C:\ArenaOS\config\.env` se crea y se usa.
- `C:\ArenaOS\backups`, `C:\ArenaOS\logs` y `C:\ArenaOS\updates` se crean.
- Doctor en verde.
- Backup manual funciona.
- Backup automático diario funciona y solo crea uno por día.
- Desinstalar/reinstalar no borra `C:\ArenaOS`.
- Update checker funciona.
- Descarga segura con SHA256 funciona.
- Aplicar update funciona.
- Feed real por GitHub configurado.
- Updates no deben tocar `C:\ArenaOS\config`, `backups`, `logs` ni `updates`.
- Antes de aplicar update, ArenaOS debe crear backup.

## Carpeta local protegida

ArenaOS conserva datos/configuración fuera de la carpeta instalada:

```txt
C:\ArenaOS
C:\ArenaOS\config
C:\ArenaOS\backups
C:\ArenaOS\logs
C:\ArenaOS\updates
```

El desinstalador no debe borrar esa carpeta.

## Variables críticas de producción

El installer debe crear `C:\ArenaOS\config\.env` si no existe. Si ya existe, debe respetarlo.

Valores esperados para producción Club Versus:

```env
NODE_ENV=production
PORT=3000
DATABASE_URL=postgresql://postgres:Versus102126@localhost:5432/club_versus_pos
JWT_SECRET=club-versus-local-secret-cambiar-luego
APP_NAME=ArenaOS
APP_VERSION=2.1.27
BUSINESS_NAME=Club Versus
CURRENCY=RD$
DESKTOP_SERVER_HOST=127.0.0.1
DESKTOP_SERVER_PORT=3000
DESKTOP_KIOSK=true
ARENAOS_UPDATE_FEED_URL=https://raw.githubusercontent.com/garicabrera95/arenaos-updates/main/latest.json
ARENAOS_UPDATE_CHECK_INTERVAL_HOURS=6
```

> Nota: cambiar `JWT_SECRET` y password de PostgreSQL cuando se defina credencial final del club.

## Feed oficial de updates

El feed real de producción queda en:

```txt
https://raw.githubusercontent.com/garicabrera95/arenaos-updates/main/latest.json
```

Repositorio del feed:

```txt
https://github.com/garicabrera95/arenaos-updates
```

Cada release debe publicar un `latest.json` con versión, URL del ZIP y SHA256.

## Validación antes de instalar

Desde el proyecto fuente:

```powershell
npm test
npm run doctor
```

Si faltan tablas en una instalación nueva:

```powershell
npm run db:setup
```

## Ejecutar en desarrollo

```powershell
npm run desktop
```

## Generar carpeta portable

```powershell
npm run pack:win
```

Esto genera una carpeta en `dist/` para probar la app empaquetada sin instalar.

## Generar instalador Windows

```powershell
npm run installer:win
```

Esto genera un instalador tipo:

```txt
ArenaOS-Setup-2.1.27.exe
```

## Backups

Crear backup manual:

```powershell
npm run backup
```

Antes de aplicar un update, ArenaOS debe crear backup automático en:

```txt
C:\ArenaOS\backups
```

## Checklist final para PC real del club

1. Instalar PostgreSQL en Windows.
2. Crear base `club_versus_pos`.
3. Instalar ArenaOS con `ArenaOS-Setup-2.1.27.exe`.
4. Confirmar que existe `C:\ArenaOS\config\.env`.
5. Confirmar que existen `C:\ArenaOS\backups`, `logs` y `updates`.
6. Abrir ArenaOS.
7. Confirmar login por PIN.
8. Confirmar estaciones.
9. Confirmar venta rápida.
10. Confirmar apertura de caja.
11. Ejecutar doctor.
12. Crear backup manual.
13. Confirmar backup automático diario.
14. Confirmar que el update checker lee GitHub.
15. Probar desinstalar/reinstalar y confirmar que `C:\ArenaOS` no se borra.
16. Probar update real desde GitHub en una versión controlada.

## Nota sobre PostgreSQL

En esta fase el instalador todavía no instala PostgreSQL automáticamente. Para el primer deployment del club, PostgreSQL se instala manualmente y ArenaOS usa la base local `club_versus_pos`.
