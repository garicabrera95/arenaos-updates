(function () {
  window.ClubVersusModules = window.ClubVersusModules || {};

  let updateStatusCache = null;
  let removeUpdateListener = null;

  function desktop() {
    return window.clubVersusDesktop || null;
  }

  function isDesktopReady() {
    const api = desktop();
    return Boolean(api?.getUpdateStatus && api?.checkUpdates);
  }

  function safeEscape(value) {
    if (typeof escapeHtml === 'function') return escapeHtml(String(value ?? ''));
    return String(value ?? '')
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#039;');
  }

  function formatCheckedAt(value) {
    if (!value) return 'Sin buscar todavía';
    try {
      return new Date(value).toLocaleString('es-DO', {
        hour: 'numeric',
        minute: '2-digit',
        year: 'numeric',
        month: '2-digit',
        day: '2-digit'
      });
    } catch {
      return value;
    }
  }


  function normalizeVersionPart(value) {
    const parsed = Number.parseInt(String(value || '').replace(/\D.*/, ''), 10);
    return Number.isFinite(parsed) ? parsed : 0;
  }

  function compareVersions(a, b) {
    const left = String(a || '0.0.0').split(/[.-]/).map(normalizeVersionPart);
    const right = String(b || '0.0.0').split(/[.-]/).map(normalizeVersionPart);
    const length = Math.max(left.length, right.length, 3);
    for (let index = 0; index < length; index += 1) {
      const diff = (left[index] || 0) - (right[index] || 0);
      if (diff > 0) return 1;
      if (diff < 0) return -1;
    }
    return 0;
  }

  function getInstalledVersionFromStatus(status = updateStatusCache || {}) {
    const config = status.config || status.updateConfig || {};
    const last = status.lastUpdateCheck || status;
    return String(status.installedVersion || config.installedVersion || last.installedVersion || '').trim();
  }

  function getDownloadedVersion(downloaded = null) {
    if (!downloaded) return '';
    if (downloaded.version) return String(downloaded.version).trim();
    const name = String(downloaded.name || downloaded.file || '');
    const match = name.match(/(\d+\.\d+\.\d+(?:[-.]\d+)?)/);
    return match ? match[1] : '';
  }

  function hasApplicableDownloadedUpdate(status = updateStatusCache || {}) {
    const downloaded = getDownloadedFromStatus(status);
    if (!downloaded?.file) return false;

    const installedVersion = getInstalledVersionFromStatus(status);
    const latest = getLatestFromStatus(status) || {};
    const last = status.lastUpdateCheck || status;
    const candidateVersion = String(latest.version || downloaded.version || getDownloadedVersion(downloaded) || '').trim();

    if (candidateVersion && installedVersion && compareVersions(candidateVersion, installedVersion) <= 0) {
      return false;
    }

    if (latest.version && last.updateAvailable === false) return false;
    return true;
  }

  function formatBytes(value) {
    const bytes = Number(value || 0);
    if (!Number.isFinite(bytes) || bytes <= 0) return '';
    if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
    return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
  }

  function getLatestFromStatus(status = updateStatusCache || {}) {
    return status.latest || status.lastUpdateCheck?.latest || null;
  }

  function getDownloadedFromStatus(status = updateStatusCache || {}) {
    const last = status.lastUpdateCheck || status;
    return status.downloadedUpdate || last.downloaded || null;
  }

  function getUpdateStateFromStatus(status = updateStatusCache || {}) {
    const last = status.lastUpdateCheck || status;
    return status.updateState || last.applied || null;
  }

  function canDownloadFromStatus(status = updateStatusCache || {}) {
    const latest = getLatestFromStatus(status) || {};
    const last = status.lastUpdateCheck || status;
    return Boolean(last.updateAvailable && latest.downloadUrl && latest.sha256 && desktop()?.downloadUpdate);
  }

  function canApplyFromStatus(status = updateStatusCache || {}) {
    const updateState = getUpdateStateFromStatus(status);
    if (updateState?.pendingRestart || updateState?.status === 'applied') return false;
    return Boolean(hasApplicableDownloadedUpdate(status) && desktop()?.applyUpdate);
  }

  function setVersionPills(version) {
    const text = version ? `v${version}` : 'v--';
    document.querySelectorAll('.app-version-pill').forEach((pill) => {
      pill.textContent = text;
    });
  }

  function closeModuleHubSafe() {
    if (typeof closeModuleHub === 'function') closeModuleHub();
  }

  function openUpdatesModule() {
    closeModuleHubSafe();
    const modal = document.querySelector('#updatesModuleModal');
    if (!modal) return;
    modal.classList.remove('hidden');
    modal.setAttribute('aria-hidden', 'false');
    loadUpdateStatus();
  }

  function closeUpdatesModule() {
    if (typeof closeConfigModule === 'function') closeConfigModule('#updatesModuleModal');
    else {
      const modal = document.querySelector('#updatesModuleModal');
      modal?.classList.add('hidden');
      modal?.setAttribute('aria-hidden', 'true');
    }
  }

  function openUpdateAvailableModal(result) {
    renderUpdateAvailable(result);
    const modal = document.querySelector('#updateAvailableModal');
    if (!modal) return;
    modal.classList.remove('hidden');
    modal.setAttribute('aria-hidden', 'false');
  }

  function closeUpdateAvailableModal() {
    const modal = document.querySelector('#updateAvailableModal');
    if (!modal) return;
    modal.classList.add('hidden');
    modal.setAttribute('aria-hidden', 'true');
  }

  function renderUpdateAvailable(result = {}) {
    const latest = result.latest || {};
    const title = document.querySelector('#updateAvailableTitle');
    const meta = document.querySelector('#updateAvailableMeta');
    const notes = document.querySelector('#updateAvailableNotes');
    const downloadHint = document.querySelector('#updateAvailableDownloadHint');

    if (title) title.textContent = latest.title || `ArenaOS ${latest.version || ''}`.trim() || 'Actualización disponible';
    if (meta) meta.textContent = `Instalada: v${result.installedVersion || '--'} · Nueva: v${latest.version || '--'}`;

    const noteItems = Array.isArray(latest.notes) ? latest.notes : [];
    if (notes) {
      notes.innerHTML = noteItems.length
        ? noteItems.map((item) => `<li>${safeEscape(item)}</li>`).join('')
        : '<li>Esta actualización no incluye notas detalladas todavía.</li>';
    }

    if (downloadHint) {
      if (getUpdateStateFromStatus()?.pendingRestart) {
        downloadHint.textContent = 'La actualización ya fue aplicada. Reinicia ArenaOS para completar.';
      } else if (getDownloadedFromStatus()) {
        downloadHint.textContent = 'El ZIP ya está descargado y verificado. Puedes aplicarlo cuando no estés en medio de una venta.';
      } else if (latest.downloadUrl && latest.sha256) {
        downloadHint.textContent = 'Puedes descargar el ZIP ahora. ArenaOS verificará el SHA256 antes de aceptarlo.';
      } else if (latest.downloadUrl && !latest.sha256) {
        downloadHint.textContent = 'El feed trae URL de descarga, pero falta sha256. Por seguridad no se descargará.';
      } else {
        downloadHint.textContent = 'Esta actualización no tiene URL de descarga todavía.';
      }
    }

    const popupDownloadBtn = document.querySelector('#downloadUpdateFromPopupBtn');
    const popupApplyBtn = document.querySelector('#applyUpdateFromPopupBtn');
    if (popupDownloadBtn) popupDownloadBtn.disabled = !canDownloadFromStatus({ lastUpdateCheck: result });
    if (popupApplyBtn) popupApplyBtn.disabled = !canApplyFromStatus(updateStatusCache || { lastUpdateCheck: result });
  }

  function renderApplyStatus(status = updateStatusCache || {}) {
    const applyStatusEl = document.querySelector('#updatesApplyStatus');
    const applyBtn = document.querySelector('#applyUpdateBtn');
    const popupApplyBtn = document.querySelector('#applyUpdateFromPopupBtn');
    const restartBtn = document.querySelector('#restartArenaOsBtn');
    const downloaded = getDownloadedFromStatus(status);
    const updateState = getUpdateStateFromStatus(status);

    if (applyStatusEl) {
      applyStatusEl.className = 'updates-download-card updates-apply-card';
      if (updateState?.pendingRestart || updateState?.status === 'applied') {
        applyStatusEl.classList.add('success');
        applyStatusEl.innerHTML = `<div><span>Aplicación segura</span><strong>Update aplicado · reinicio pendiente</strong><small>Backup: ${safeEscape(updateState.backupFile || 'creado')} · Archivos copiados: ${Number(updateState.copiedCount || 0)}</small></div>`;
      } else if (updateState?.status === 'completed') {
        applyStatusEl.classList.add('success');
        applyStatusEl.innerHTML = `<div><span>Aplicación segura</span><strong>Update completado</strong><small>Versión ${safeEscape(updateState.targetVersion || '')} confirmada después del reinicio.</small></div>`;
      } else if (updateState?.status === 'error') {
        applyStatusEl.classList.add('error');
        applyStatusEl.innerHTML = `<div><span>Aplicación segura</span><strong>No se pudo aplicar</strong><small>${safeEscape(updateState.error || 'Revisa el log de updates.')}</small></div>`;
      } else if (downloaded?.file && hasApplicableDownloadedUpdate(status)) {
        applyStatusEl.classList.add('available');
        applyStatusEl.innerHTML = '<div><span>Aplicación segura</span><strong>Lista para aplicar</strong><small>Se creará un backup antes de copiar archivos. Aplica cuando no haya ventas en curso.</small></div>';
      } else if (downloaded?.file) {
        applyStatusEl.classList.add('success');
        applyStatusEl.innerHTML = '<div><span>Aplicación segura</span><strong>Sin update pendiente</strong><small>El ZIP descargado ya no requiere aplicación para la versión instalada.</small></div>';
      } else {
        applyStatusEl.classList.add('muted');
        applyStatusEl.innerHTML = '<div><span>Aplicación segura</span><strong>Sin update aplicado</strong><small>Cuando descargues un update verificado, podrás aplicarlo con backup previo.</small></div>';
      }
    }

    const canApply = canApplyFromStatus(status);
    if (applyBtn) applyBtn.disabled = !canApply;
    if (popupApplyBtn) popupApplyBtn.disabled = !canApply;
    if (restartBtn) restartBtn.classList.toggle('hidden', !(updateState?.pendingRestart || updateState?.status === 'applied'));
  }

  function renderUpdateStatus(result) {
    updateStatusCache = result || updateStatusCache || {};
    const config = updateStatusCache.config || updateStatusCache.updateConfig || {};
    const last = updateStatusCache.lastUpdateCheck || updateStatusCache;
    const installedVersion = updateStatusCache.installedVersion || config.installedVersion || last.installedVersion || '';

    setVersionPills(installedVersion);

    const versionEl = document.querySelector('#updatesInstalledVersion');
    const feedEl = document.querySelector('#updatesFeedStatus');
    const intervalEl = document.querySelector('#updatesIntervalStatus');
    const lastEl = document.querySelector('#updatesLastCheck');
    const statusEl = document.querySelector('#updatesStatusMessage');
    const checkBtn = document.querySelector('#checkUpdatesNowBtn');
    const downloadBtn = document.querySelector('#downloadUpdateBtn');
    const downloadStatusEl = document.querySelector('#updatesDownloadStatus');

    if (versionEl) versionEl.textContent = installedVersion ? `v${installedVersion}` : 'No detectada';
    if (feedEl) feedEl.textContent = config.feedUrl ? config.feedUrl : 'No configurado';
    if (intervalEl) intervalEl.textContent = `${Number(config.intervalHours || 6)} hora(s)`;
    if (lastEl) lastEl.textContent = formatCheckedAt(last.checkedAt);

    if (statusEl) {
      statusEl.className = 'updates-status-card';
      if (!isDesktopReady()) {
        statusEl.classList.add('error');
        statusEl.innerHTML = '<strong>Desktop no detectado</strong><span>Abre ArenaOS desde la app instalada para buscar actualizaciones.</span>';
      } else if (last.configured === false || !config.feedUrl) {
        statusEl.classList.add('muted');
        statusEl.innerHTML = '<strong>Servidor no configurado</strong><span>Agrega ARENAOS_UPDATE_FEED_URL en C:\\ArenaOS\\config\\.env cuando tengas el feed listo.</span>';
      } else if (last.ok === false) {
        statusEl.classList.add('error');
        statusEl.innerHTML = `<strong>No se pudo buscar</strong><span>${safeEscape(last.message || 'Revisa internet o el feed de updates.')}</span>`;
      } else if (last.updateAvailable) {
        statusEl.classList.add('available');
        statusEl.innerHTML = `<strong>Actualización disponible</strong><span>Instalada v${safeEscape(last.installedVersion || '--')} · Nueva v${safeEscape(last.latest?.version || '--')}</span>`;
      } else if (last.checkedAt) {
        statusEl.classList.add('success');
        statusEl.innerHTML = `<strong>Todo al día</strong><span>${safeEscape(last.message || 'ArenaOS está actualizado.')}</span>`;
      } else {
        statusEl.innerHTML = '<strong>Listo para buscar</strong><span>Presiona “Buscar actualizaciones” para revisar manualmente.</span>';
      }
    }

    if (downloadStatusEl) {
      const downloaded = getDownloadedFromStatus(updateStatusCache);
      const latest = getLatestFromStatus(updateStatusCache) || {};
      downloadStatusEl.className = 'updates-download-card';
      if (downloaded?.file) {
        downloadStatusEl.classList.add('success');
        downloadStatusEl.innerHTML = `<div><span>Descarga segura</span><strong>${safeEscape(downloaded.name || 'Update descargado')}</strong><small>${safeEscape(formatBytes(downloaded.sizeBytes) || '')} · Guardado en C:\\ArenaOS\\updates</small></div>`;
      } else if (last.updateAvailable && latest.downloadUrl && latest.sha256) {
        downloadStatusEl.classList.add('available');
        downloadStatusEl.innerHTML = `<div><span>Descarga segura</span><strong>Lista para descargar</strong><small>Versión v${safeEscape(latest.version || '--')} · Se verificará con SHA256 antes de aceptar el ZIP.</small></div>`;
      } else if (last.updateAvailable && latest.downloadUrl && !latest.sha256) {
        downloadStatusEl.classList.add('error');
        downloadStatusEl.innerHTML = '<div><span>Descarga segura</span><strong>Falta SHA256</strong><small>El feed tiene downloadUrl, pero falta sha256. ArenaOS no descargará ese update por seguridad.</small></div>';
      } else {
        downloadStatusEl.classList.add('muted');
        downloadStatusEl.innerHTML = '<div><span>Descarga segura</span><strong>Sin update descargado</strong><small>Cuando haya una versión nueva, podrás descargar el ZIP verificado a C:\\ArenaOS\\updates.</small></div>';
      }
    }

    if (checkBtn) checkBtn.disabled = !isDesktopReady();
    if (downloadBtn) downloadBtn.disabled = !canDownloadFromStatus(updateStatusCache);
    renderApplyStatus(updateStatusCache);
  }

  async function loadUpdateStatus() {
    if (!isDesktopReady()) {
      renderUpdateStatus({ config: {}, lastUpdateCheck: { configured: false } });
      return null;
    }
    try {
      const result = await desktop().getUpdateStatus();
      renderUpdateStatus(result || {});
      return result;
    } catch (error) {
      renderUpdateStatus({ ok: false, message: error.message || 'No se pudo leer estado de updates.' });
      return null;
    }
  }

  async function checkUpdatesNow() {
    if (!isDesktopReady()) {
      if (typeof showToast === 'function') showToast('Desktop no detectado');
      return null;
    }

    const btn = document.querySelector('#checkUpdatesNowBtn');
    if (btn) {
      btn.disabled = true;
      btn.textContent = 'Buscando...';
    }

    try {
      const result = await desktop().checkUpdates({ manual: true, notify: false });
      const status = await desktop().getUpdateStatus().catch(() => null);
      renderUpdateStatus(status || result || {});

      if (result?.updateAvailable) {
        openUpdateAvailableModal(result);
      } else if (typeof showToast === 'function') {
        showToast(result?.message || 'Búsqueda completada');
      }
      return result;
    } catch (error) {
      const result = { ok: false, message: error.message || 'No se pudo buscar actualización.' };
      renderUpdateStatus(result);
      if (typeof showToast === 'function') showToast(result.message);
      return result;
    } finally {
      if (btn) {
        btn.disabled = false;
        btn.textContent = 'Buscar actualizaciones';
      }
    }
  }

  async function downloadUpdateNow(source = 'module') {
    if (!desktop()?.downloadUpdate) {
      if (typeof showToast === 'function') showToast('Descarga de updates no disponible en esta versión');
      return null;
    }

    const moduleBtn = document.querySelector('#downloadUpdateBtn');
    const popupBtn = document.querySelector('#downloadUpdateFromPopupBtn');
    const touchedBtn = source === 'popup' ? popupBtn : moduleBtn;
    [moduleBtn, popupBtn].forEach((btn) => {
      if (!btn) return;
      btn.disabled = true;
      btn.dataset.previousText = btn.textContent || '';
      btn.textContent = 'Descargando...';
    });

    try {
      const result = await desktop().downloadUpdate({ forceCheck: false });
      const status = await desktop().getUpdateStatus().catch(() => null);
      renderUpdateStatus(status || result || {});
      if (result?.ok) {
        closeUpdateAvailableModal();
        openUpdatesModule();
        if (typeof showToast === 'function') showToast(result.message || 'Update descargado y verificado');
      } else if (typeof showToast === 'function') {
        showToast(result?.message || 'No se pudo descargar la actualización');
      }
      return result;
    } catch (error) {
      const message = error.message || 'No se pudo descargar la actualización.';
      renderUpdateStatus({ ...(updateStatusCache || {}), ok: false, message });
      if (typeof showToast === 'function') showToast(message);
      return { ok: false, message };
    } finally {
      [moduleBtn, popupBtn].forEach((btn) => {
        if (!btn) return;
        btn.textContent = btn.dataset.previousText || (btn === popupBtn ? 'Descargar' : 'Descargar actualización');
        delete btn.dataset.previousText;
      });
      const status = await loadUpdateStatus().catch(() => null);
      if (!status && touchedBtn) touchedBtn.disabled = false;
    }
  }

  async function applyUpdateNow(source = 'module') {
    if (!desktop()?.applyUpdate) {
      if (typeof showToast === 'function') showToast('Aplicación de updates no disponible en esta versión');
      return null;
    }

    const moduleBtn = document.querySelector('#applyUpdateBtn');
    const popupBtn = document.querySelector('#applyUpdateFromPopupBtn');
    const downloadBtn = document.querySelector('#downloadUpdateBtn');
    const checkBtn = document.querySelector('#checkUpdatesNowBtn');
    [moduleBtn, popupBtn, downloadBtn, checkBtn].forEach((btn) => {
      if (!btn) return;
      btn.disabled = true;
      btn.dataset.previousText = btn.textContent || '';
    });
    if (moduleBtn) moduleBtn.textContent = 'Aplicando...';
    if (popupBtn) popupBtn.textContent = 'Aplicando...';

    try {
      const result = await desktop().applyUpdate({ source });
      const status = await desktop().getUpdateStatus().catch(() => null);
      renderUpdateStatus(status || result || {});
      closeUpdateAvailableModal();
      openUpdatesModule();
      if (typeof showToast === 'function') showToast(result?.message || 'Update aplicado. Reinicia ArenaOS.');
      return result;
    } catch (error) {
      const message = error.message || 'No se pudo aplicar la actualización.';
      const status = await desktop().getUpdateStatus().catch(() => null);
      renderUpdateStatus(status || { ...(updateStatusCache || {}), ok: false, message });
      if (typeof showToast === 'function') showToast(message);
      return { ok: false, message };
    } finally {
      [moduleBtn, popupBtn, downloadBtn, checkBtn].forEach((btn) => {
        if (!btn) return;
        btn.textContent = btn.dataset.previousText || btn.textContent;
        delete btn.dataset.previousText;
      });
      await loadUpdateStatus().catch(() => null);
    }
  }

  async function restartArenaOs() {
    if (!desktop()?.restartApp) {
      if (typeof showToast === 'function') showToast('Reinicio no disponible en esta versión');
      return;
    }
    await desktop().restartApp();
  }

  function bindUpdateEvents() {
    document.querySelector('#closeUpdatesModuleBtn')?.addEventListener('click', closeUpdatesModule);
    document.querySelector('#updatesModuleBackdrop')?.addEventListener('click', closeUpdatesModule);
    document.querySelector('#checkUpdatesNowBtn')?.addEventListener('click', checkUpdatesNow);
    document.querySelector('#downloadUpdateBtn')?.addEventListener('click', () => downloadUpdateNow('module'));
    document.querySelector('#applyUpdateBtn')?.addEventListener('click', () => applyUpdateNow('module'));
    document.querySelector('#restartArenaOsBtn')?.addEventListener('click', restartArenaOs);
    document.querySelector('#closeUpdateAvailableBtn')?.addEventListener('click', closeUpdateAvailableModal);
    document.querySelector('#remindUpdateLaterBtn')?.addEventListener('click', closeUpdateAvailableModal);
    document.querySelector('#downloadUpdateFromPopupBtn')?.addEventListener('click', () => downloadUpdateNow('popup'));
    document.querySelector('#applyUpdateFromPopupBtn')?.addEventListener('click', () => applyUpdateNow('popup'));
    document.querySelector('#openUpdatesFromPopupBtn')?.addEventListener('click', () => {
      closeUpdateAvailableModal();
      openUpdatesModule();
    });
    document.querySelector('#updateAvailableBackdrop')?.addEventListener('click', closeUpdateAvailableModal);

    if (desktop()?.onUpdateAvailable && !removeUpdateListener) {
      removeUpdateListener = desktop().onUpdateAvailable((result) => {
        renderUpdateStatus({ config: result?.config || {}, lastUpdateCheck: result });
        openUpdateAvailableModal(result);
      });
    }
  }

  document.addEventListener('DOMContentLoaded', () => {
    bindUpdateEvents();
    loadUpdateStatus();
  });

  window.openUpdatesModule = openUpdatesModule;
  window.closeUpdatesModule = closeUpdatesModule;
  window.checkUpdatesNow = checkUpdatesNow;
  window.downloadUpdateNow = downloadUpdateNow;
  window.applyUpdateNow = applyUpdateNow;
  window.restartArenaOs = restartArenaOs;

  window.ClubVersusUpdates = {
    openUpdatesModule,
    closeUpdatesModule,
    loadUpdateStatus,
    checkUpdatesNow,
    downloadUpdateNow,
    applyUpdateNow,
    restartArenaOs,
    openUpdateAvailableModal,
    closeUpdateAvailableModal
  };

  window.ClubVersusModules.updates = window.ClubVersusUpdates;
})();
