# ArenaOS 2.1.24 - GitHub feed test

Update pequeño para validar descarga y aplicación desde GitHub.

Incluye:
- Versión 2.1.24 en package.json/package-lock.json.
- APP_VERSION 2.1.24 en defaults de escritorio.
- Ejemplos de feed actualizados.

No toca base de datos, configuración local, backups ni lógica de ventas.
